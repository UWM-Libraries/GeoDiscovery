import{O as e}from"./index-pmp42xxj-BQ59Wf1I.js";document.addEventListener("DOMContentLoaded",()=>{new e().run()});
